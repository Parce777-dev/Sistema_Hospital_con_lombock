import entidades.*;
import repositorios.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Repositorios
        HospitalRepository hospitalRepo = new HospitalRepository();
        DepartamentoRepository departamentoRepo = new DepartamentoRepository();
        SalaRepository salaRepo = new SalaRepository();
        MedicoRepository medicoRepo = new MedicoRepository();
        PacienteRepository pacienteRepo = new PacienteRepository();
        CitaRepository citaRepo = new CitaRepository();

        CitaManager citaManager = new CitaManager();

        // Crear hospitales
        Hospital h1 = Hospital.builder().nombre("Hospital Central").direccion("Av. San Martín 100").telefono("261-111-1111").build();
        Hospital h2 = Hospital.builder().nombre("Hospital del Este").direccion("Calle Mitre 200").telefono("261-222-2222").build();
        hospitalRepo.save(h1);
        hospitalRepo.save(h2);

        // Crear departamentos
        Departamento cardio = Departamento.builder().nombre("Cardiología").especialidad(EspecialidadMedica.CARDIOLOGIA).hospital(h1).build();
        Departamento neuro = Departamento.builder().nombre("Neurología").especialidad(EspecialidadMedica.NEUROLOGIA).hospital(h1).build();
        Departamento trauma = Departamento.builder().nombre("Traumatología").especialidad(EspecialidadMedica.TRAUMATOLOGIA).hospital(h2).build();
        h1.agregarDepartamento(cardio);
        h1.agregarDepartamento(neuro);
        h2.agregarDepartamento(trauma);
        departamentoRepo.save(cardio);
        departamentoRepo.save(neuro);
        departamentoRepo.save(trauma);

        // Crear salas
        Sala s1 = Sala.builder().numero("101").tipo("Consultorio").departamento(cardio).build();
        Sala s2 = Sala.builder().numero("102").tipo("Consultorio").departamento(neuro).build();
        Sala s3 = Sala.builder().numero("201").tipo("Quirófano").departamento(trauma).build();
        salaRepo.save(s1);
        salaRepo.save(s2);
        salaRepo.save(s3);

        // Crear médicos
        Medico m1 = Medico.builder().nombre("Ana").apellido("Gómez").dni("12345678").fechaNacimiento(LocalDate.of(1980, 5, 20)).tipoSangre(TipoSangre.A_POSITIVO).matricula(new Matricula("MP-1001")).especialidad(EspecialidadMedica.CARDIOLOGIA).build();
        Medico m2 = Medico.builder().nombre("Carlos").apellido("López").dni("23456789").fechaNacimiento(LocalDate.of(1975, 8, 10)).tipoSangre(TipoSangre.B_NEGATIVO).matricula(new Matricula("MP-1002")).especialidad(EspecialidadMedica.NEUROLOGIA).build();
        Medico m3 = Medico.builder().nombre("Lucía").apellido("Martínez").dni("34567890").fechaNacimiento(LocalDate.of(1985, 3, 5)).tipoSangre(TipoSangre.O_POSITIVO).matricula(new Matricula("MP-1003")).especialidad(EspecialidadMedica.TRAUMATOLOGIA).build();
        m1.setDepartamento(cardio);
        m2.setDepartamento(neuro);
        m3.setDepartamento(trauma);
        medicoRepo.save(m1);
        medicoRepo.save(m2);
        medicoRepo.save(m3);

        // Crear pacientes
        Paciente p1 = Paciente.builder().nombre("Luis").apellido("Pérez").dni("87654321").fechaNacimiento(LocalDate.of(1990, 3, 15)).tipoSangre(TipoSangre.O_NEGATIVO).telefono("261-888-9999").direccion("Calle Falsa 123").build();
        Paciente p2 = Paciente.builder().nombre("María").apellido("Fernández").dni("76543210").fechaNacimiento(LocalDate.of(1995, 7, 22)).tipoSangre(TipoSangre.A_NEGATIVO).telefono("261-777-8888").direccion("Calle Real 456").build();
        Paciente p3 = Paciente.builder().nombre("Jorge").apellido("Ramírez").dni("65432109").fechaNacimiento(LocalDate.of(1988, 12, 1)).tipoSangre(TipoSangre.B_POSITIVO).telefono("261-666-7777").direccion("Calle Norte 789").build();
        p1.setHospital(h1);
        p2.setHospital(h1);
        p3.setHospital(h2);
        pacienteRepo.save(p1);
        pacienteRepo.save(p2);
        pacienteRepo.save(p3);

        // Programar citas
        List<Cita> citas = new ArrayList<>();
        try {
            citas.add(citaManager.programarCita(p1, m1, s1, LocalDateTime.now().plusDays(1).withHour(9), BigDecimal.valueOf(5000)));
            citas.add(citaManager.programarCita(p2, m2, s2, LocalDateTime.now().plusDays(2).withHour(10), BigDecimal.valueOf(6000)));
            citas.add(citaManager.programarCita(p3, m3, s3, LocalDateTime.now().plusDays(3).withHour(11), BigDecimal.valueOf(7000)));
            citas.add(citaManager.programarCita(p1, m1, s1, LocalDateTime.now().plusDays(4).withHour(9), BigDecimal.valueOf(5500))); // segunda cita con mismo médico
        } catch (CitaException e) {
            System.err.println("Error al programar cita: " + e.getMessage());
        }
        citas.forEach(citaRepo::save);

        // Cancelar una cita
        if (!citas.isEmpty()) {
            Cita citaCancelada = citas.get(0);
            citaCancelada.setEstado(EstadoCita.CANCELADA);
            System.out.println("-- Cita cancelada: " + citaCancelada.getFechaHora());
        }

        // Modificar paciente
        p1.setTelefono("261-999-0000");
        pacienteRepo.genericUpdate(p1.getId(), p1);

        // Eliminar médico
        medicoRepo.genericDelete(m2.getId());

        // Buscar pacientes por DNI
        List<Paciente> encontrados = pacienteRepo.genericFindByField("dni", "87654321");
        System.out.println("\n-- Búsqueda por DNI '87654321':");
        encontrados.forEach(p -> System.out.println("👤 " + p.getNombre() + " " + p.getApellido()));

        // Mostrar estadísticas
        System.out.println("\n-- Estadísticas generales:");
        System.out.println("-- Hospitales: " + hospitalRepo.findAll().size());
        System.out.println("-- Departamentos: " + departamentoRepo.findAll().size());
        System.out.println("-- Salas: " + salaRepo.findAll().size());
        System.out.println("-- Médicos: " + medicoRepo.findAll().size());
        System.out.println("-- Pacientes: " + pacienteRepo.findAll().size());
        System.out.println("-- Citas totales: " + citaRepo.findAll().size());

        // Mostrar citas por paciente
        System.out.println("\n-- Citas de " + p1.getNombre() + ":");
        p1.getCitas().forEach(c -> System.out.println("🕒 " + c.getFechaHora() + " con Dr. " + c.getMedico().getApellido()));

        // Mostrar citas por sala
        System.out.println("\n-- Citas en sala " + s1.getNumero() + ":");
        s1.getCitas().forEach(c -> System.out.println("📅 " + c.getFechaHora() + " - Paciente: " + c.getPaciente().getNombre()));

        // Mostrar citas por estado
        System.out.println("\n-- Citas canceladas:");
        citaRepo.findAll().stream()
                .filter(c -> c.getEstado() == EstadoCita.CANCELADA)
                .forEach(c -> System.out.println("❌ " + c.getFechaHora() + " - " + c.getPaciente().getNombre()));
    }
}