package entidades;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Getter
@Setter
@ToString(exclude = {"departamentos", "pacientes"})
@Builder
public class Hospital implements Serializable {
    private Long id;
    private final String nombre;
    private final String direccion;
    private final String telefono;
    private final List<Departamento> departamentos = new ArrayList<>();
    private final List<Paciente> pacientes = new ArrayList<>();

    public void agregarDepartamento(Departamento departamento) {
        if (departamento != null && !departamentos.contains(departamento)) {
            departamentos.add(departamento);
        }
    }

    public void agregarPaciente(Paciente paciente) {
        if (paciente != null && !pacientes.contains(paciente)) {
            pacientes.add(paciente);
        }
    }

    public void removerPaciente(Paciente paciente) {
        pacientes.remove(paciente);
    }

    public List<Departamento> getDepartamentos() {
        return Collections.unmodifiableList(departamentos);
    }

    public List<Paciente> getInternalPacientes() {
        return pacientes;
    }

    public List<Paciente> getPacientes() {
        return Collections.unmodifiableList(pacientes);
    }

    public String getNombre() {
        return Objects.requireNonNull(nombre, "El nombre del hospital no puede ser nulo");
    }

    public String getDireccion() {
        return Objects.requireNonNull(direccion, "La dirección del hospital no puede ser nula");
    }

    public String getTelefono() {
        return Objects.requireNonNull(telefono, "El teléfono del hospital no puede ser nulo");
    }
}