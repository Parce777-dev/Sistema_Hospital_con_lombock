package entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
@Setter
@ToString(callSuper = true, exclude = {"citas"})
@SuperBuilder
public class Medico extends Persona implements Serializable {
    private Long id;
    private final Matricula matricula;
    private final EspecialidadMedica especialidad;
    private final List<Cita> citas = new ArrayList<>();
    private Departamento departamento;

    public Medico(MedicoBuilder<?, ?> builder) {
        super(builder);
        this.matricula = builder.matricula;
        this.especialidad = builder.especialidad;
    }

    public static abstract class MedicoBuilder<C extends Medico, B extends MedicoBuilder<C, B>> extends PersonaBuilder<C, B> {
        private Matricula matricula;
        private EspecialidadMedica especialidad;

        public B matricula(Matricula matricula) {
            this.matricula = matricula;
            return self();
        }

        public B especialidad(EspecialidadMedica especialidad) {
            this.especialidad = especialidad;
            return self();
        }
    }

    public void addCita(Cita cita) {
        if (cita != null && !citas.contains(cita)) {
            citas.add(cita);
        }
    }

    public List<Cita> getCitas() {
        return Collections.unmodifiableList(citas);
    }

    public void setDepartamento(Departamento departamento) {
        if (this.departamento != departamento) {
            if (this.departamento != null) {
                this.departamento.getMedicos().remove(this);
            }
            this.departamento = departamento;
            if (departamento != null) {
                departamento.agregarMedico(this);
            }
        }
    }
}