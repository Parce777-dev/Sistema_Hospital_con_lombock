package entidades;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

@Getter
@Setter
@ToString
@Builder
public class Cita implements Serializable {
    private Long id;
    private final Paciente paciente;
    private final Medico medico;
    private final Sala sala;
    private final LocalDateTime fechaHora;
    private final BigDecimal costo;
    private EstadoCita estado;

    public String toCsvString() {
        return paciente.getDni() + "," +
                medico.getDni() + "," +
                sala.getNumero() + "," +
                fechaHora + "," +
                costo + "," +
                estado.name();
    }

    public static Cita fromCsvString(String line, Map<String, Paciente> pacientes,
                                     Map<String, Medico> medicos, Map<String, Sala> salas) throws CitaException {
        String[] parts = line.split(",");
        if (parts.length < 6) {
            throw new CitaException("Formato CSV inválido");
        }

        String dniPaciente = parts[0];
        String dniMedico = parts[1];
        String numeroSala = parts[2];
        String fechaHoraStr = parts[3];
        String costoStr = parts[4];
        String estadoStr = parts[5];

        Paciente paciente = pacientes.get(dniPaciente);
        Medico medico = medicos.get(dniMedico);
        Sala sala = salas.get(numeroSala);
        LocalDateTime fechaHora = LocalDateTime.parse(fechaHoraStr);
        BigDecimal costo = new BigDecimal(costoStr);
        EstadoCita estado = EstadoCita.valueOf(estadoStr);

        if (paciente == null || medico == null || sala == null) {
            throw new CitaException("Entidad referenciada no encontrada: paciente, médico o sala");
        }

        return Cita.builder()
                .paciente(paciente)
                .medico(medico)
                .sala(sala)
                .fechaHora(fechaHora)
                .costo(costo)
                .estado(estado)
                .build();
    }
}