package entidades;

import lombok.experimental.StandardException;

@StandardException
public class CitaException extends Exception {
}

