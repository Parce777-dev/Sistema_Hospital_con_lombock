package repositorios;

import entidades.Medico;

public class MedicoRepository extends InMemoryRepository<Medico> {}