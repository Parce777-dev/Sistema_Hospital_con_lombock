package repositorios;

import entidades.Cita;

public class CitaRepository extends InMemoryRepository<Cita> {}