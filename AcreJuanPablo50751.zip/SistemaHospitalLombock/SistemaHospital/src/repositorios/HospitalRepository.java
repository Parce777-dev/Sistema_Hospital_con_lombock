package repositorios;

import entidades.Hospital;

public class HospitalRepository extends InMemoryRepository<Hospital> {}