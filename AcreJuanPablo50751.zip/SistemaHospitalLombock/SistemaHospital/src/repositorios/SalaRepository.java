package repositorios;

import entidades.Sala;

public class SalaRepository extends InMemoryRepository<Sala> {}